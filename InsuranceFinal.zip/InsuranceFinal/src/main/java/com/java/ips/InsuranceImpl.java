package com.java.ips;

import java.io.IOException;
import java.util.List;
import java.util.Map;


import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class InsuranceImpl {

	SessionFactory sf; // it is factory of session object and declare instance of two variables related to hibernate  to handle the database session.
	Session session;
	
		

	private String localCode;// declare a private string local because if we want to add aditional logic in that and change code in future then it use in subclass

	public String getLocalCode() {
		return localCode;
	}                                           
                     
	public void setLocalCode(String localCode) {
		this.localCode = localCode;
	}
           
//	public List<Insurance_Details> showInsurance() {
//		sf = SessionHelper.getConnection();
//		session = sf.openSession();
//		Query query = session.createQuery("from Insurance_Details");
//		List<Insurance_Details> insdet = query.list();
//		return insdet;
//	}

	public String showInsurancePlans(String insurance_id) {
		//System.out.println("explore plans");
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();				
		session.beginTransaction();
		Criteria criteria = session.createCriteria(Insurance_Plans.class);
		criteria.add(Restrictions.eq("insurance_id", insurance_id));
		List<Insurance_Plans> showList = criteria.list();
		sessionMap.put("showList",showList);	
		return "showPlans.jsp?faces-redirect=true";
		
	}
	
//	public String takeToinsurancePlan(String insurance_id) {
//		System.out.println(insurance_id);
//		Map<String, Object> sessionMap = 
//		FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//		sessionMap.put("insurance_id", insurance_id);
//		return "ExplorePlans.jsp?faces-redirect=true"; 
//	}

//	public List<Insurance_Details> showInsuranceDetailsDao(int firstRow, int rowCount) {
//		sf = SessionHelper.getConnection();
//		session = sf.openSession();
//		Criteria cr = session.createCriteria(Insurance_Details.class);
//		cr.setFirstResult(firstRow);
//		cr.setMaxResults(rowCount);
//		System.out.println(firstRow);
//		System.out.println(rowCount);
//		System.out.println(cr.list());
//		return cr.list();
//	}
//	

//	public int countRows(String searchValue) {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//		Map<String, Object> sessionMap = 
//		FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//		String searchTypeStr = (String) sessionMap.get("searchTypeStr");
//		sf = SessionHelper.getConnection();
//		session = sf.openSession();
//		try {
//			session.beginTransaction();
//			Criteria criteria = session.createCriteria(Insurance_Details.class);
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return 0;
//	}
//	
	public int countRows() {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		try {
			session.beginTransaction();
			Criteria criteria = session.createCriteria(Insurance_Details.class);
			if (criteria != null) {
				return criteria.list().size();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
//	public int countRows1(String insurance_Name) {
//		SessionFactory sf = SessionHelper.getConnection();
//		Session session = sf.openSession();
//		try {
//			session.beginTransaction();
//			Criteria criteria = session.createCriteria(Insurance_Details.class);
//			if (criteria != null) {
//				if (insurance_Name.length()>0 || insurance_Name!=null) {
//					System.out.println("working");
//					criteria.add(Restrictions.like("insurance_Name", insurance_Name + "%"));
//				}
//				return criteria.list().size();
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return 0;
//	}
	
//	public List<Insurance_Details> getListOfInsurance(int firstRow, int rowCount) {
//		SessionFactory sf = SessionHelper.getConnection();
//		Session session = sf.openSession();
//		List<Insurance_Details> cdList = null;
//	    session.beginTransaction();
//		Criteria criteria = session.createCriteria(Insurance_Details.class);
//		criteria.setFirstResult(firstRow);
//		criteria.setMaxResults(rowCount);
//		return criteria.list();
//	}

	
//	public String searchByinsurance_id(int insurance_id) {
//		sf = SessionHelper.getConnection();
//		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//		session = sf.openSession();
//		Criteria criteria = session.createCriteria(Insurance_Details.class);
//		criteria.add(Restrictions.eq("insurance_id", insurance_id));
//		List<Insurance_Details> insList = criteria.list();
//		sessionMap.put("insList", insList);
//		return "showDetailsPaging.jsp?faces-redirect=true";
//		}
//	public String searchByinsurance_name(String insurance_Name) {
//		System.out.println("Method search hitting....");
//		sf = SessionHelper.getConnection();
//		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//	    session = sf.openSession();
//	    Criteria cr=session.createCriteria(Insurance_Details.class);
//	    cr.add(Restrictions.eq("insurance_Name", insurance_Name));
//	    List<Insurance_Details> insurance=cr.list();
//	    sessionMap.put("insurance", insurance);
//	    return "SingleInsurance.jsp?faces-redirect=true";
//	} 
	
	public String searchByinsurance_name(String insurance_Name) {
		System.out.println("method is hitting in search");
		System.out.println(insurance_Name);
 	    Session session = SessionHelper.getConnection().openSession();
    	Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		Criteria criteria = session.createCriteria(Insurance_Details.class);
		criteria.add(Restrictions.eq("insurance_Name", insurance_Name));
		Insurance_Details insurance = (Insurance_Details) criteria.uniqueResult();
		sessionMap.put("insurance", insurance);
		return "SingleInsurance.jsp?faces-redirect=true";
 
	}


	
	//--------------reset----------------------//
		public void clear() throws IOException {
			System.out.println("Reset");
			FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("InsImpl", null);
			
			ExternalContext ex = FacesContext.getCurrentInstance().getExternalContext();
			ex.redirect(((HttpServletRequest) ex.getRequest()).getRequestURI());
	        

}
                                                                      
//---------------------------------sorting-----------------------------------------------------
		public List<Insurance_Details> getListOfInsurance(int firstRow, int rowCount) {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			sf = SessionHelper.getConnection();
			session = sf.openSession();
			session.beginTransaction();
		//	System.out.println("List=====================================================");
			Criteria criteria = session.createCriteria(Insurance_Details.class);
			
			criteria.setFirstResult(firstRow);
			criteria.setMaxResults(rowCount);
																			
			if ("asc".equals(orderByinsurance_id)) {
				criteria.addOrder(Order.asc("insurance_id"));
			}
			else if ("desc".equals(orderByinsurance_id)) {
				criteria.addOrder(Order.desc("insurance_id"));
			}
			else if ("asc".equals(orderByinsurance_Name)) {
				criteria.addOrder(Order.desc("insurance_Name"));
			}
			
			else if ("asc".equals(orderBytype)) {
				criteria.addOrder(Order.asc("type"));
			}
			else if ("desc".equals(orderBytype)) {
				criteria.addOrder(Order.desc("type"));
			}
			
			
			else if ("asc".equals(orderByPremiumStart)) {
				criteria.addOrder(Order.asc("PremiumStart"));
			}
			else if ("desc".equals(orderByPremiumStart)) {
				criteria.addOrder(Order.desc("PremiumStart"));
			}
			
			
			else if ("asc".equals(orderBypremiumEnd)) {
				criteria.addOrder(Order.asc("premiumEnd"));
			}
			else if ("desc".equals(orderBypremiumEnd )) {
				criteria.addOrder(Order.desc("premiumEnd"));
			}
			
			
			else if ("asc".equals(orderBylaunchDate)) {
				criteria.addOrder(Order.asc("launchDate"));
			}
			
			else if ("desc".equals(orderBylaunchDate)) {
				criteria.addOrder(Order.desc("launchDate"));
			}
			
		
			
			else if ("asc".equals(orderBystatus)) {
				criteria.addOrder(Order.asc("status"));
			}
			
			else if ("desc".equals(orderBystatus)) {
				criteria.addOrder(Order.desc("status"));
			}
			
			
			List<Insurance_Details> Insurance_Details = criteria.list();
			session.getTransaction().commit();
			session.close();
			return Insurance_Details;
		}
	 
		static String orderByinsurance_id = "asc";
		static String orderByinsurance_Name = "sort";
		static String orderBytype = "sort";
		static String orderByPremiumStart = "sort";
		static String orderBypremiumEnd = "sort";
		static String orderBylaunchDate = "sort";
		static String orderBystatus = "sort";
		
		
	    
		public String sortByinsurance_id() {
			Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderByinsurance_id.length() == 4) {
				orderByinsurance_id = "asc";
			} else if ("asc".equals(orderByinsurance_id)) {
				orderByinsurance_id = "desc";
			}
			sessionMap.put("orderByinsurance_id", orderByinsurance_id);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}
	 
		public String sortByinsurance_Name() {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderByinsurance_Name.length() == 4) {
				orderByinsurance_Name = "asc";
				orderByinsurance_id = "sort";
			} else if ("asc".equals(orderByinsurance_Name)) {
				orderByinsurance_Name= "desc";
				orderByinsurance_id = "sort";
			}
			sessionMap.put("orderByinsurance_Name", orderByinsurance_Name);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}
		
        
		public String sortBytype() {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderBytype.length() == 4) {
				orderBytype = "asc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
			} else if ("asc".equals(orderBytype)) {
				orderBytype = "desc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
			}
			sessionMap.put("orderBytype", orderBytype);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}
		
		                                       
		public String sortByPremiumStart() {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderByPremiumStart.length() == 4) {
				orderByPremiumStart = "asc";
				orderByinsurance_id = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
			} else if ("asc".equals(orderByPremiumStart)) {
				orderByPremiumStart = "desc";
				orderByinsurance_id = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
			}
			sessionMap.put("orderByPremiumStart", orderByPremiumStart);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}	
		public String sortBypremiumEnd() {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderBypremiumEnd.length() == 4) {
				orderBypremiumEnd = "asc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
				orderByPremiumStart="sort";
			} else if ("asc".equals(orderBypremiumEnd)) {
				orderBypremiumEnd = "desc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
				orderByPremiumStart="sort";
			}
			sessionMap.put("orderBypremiumEnd", orderBypremiumEnd);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}
		
		public String sortBylaunchDate() {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderBylaunchDate.length() == 4) {
				orderBylaunchDate = "asc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
				orderByPremiumStart="sort";
				orderBypremiumEnd="sort";
			} else if ("asc".equals(orderBylaunchDate)) {
				orderBylaunchDate = "desc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
				orderByPremiumStart="sort";
				orderBypremiumEnd="sort";
			}
			sessionMap.put("orderBylaunchDate", orderBylaunchDate);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}
		
		public String sortBystatus() {
			Map<String, Object> sessionMap =
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			if (orderBystatus.length() == 4) {
				orderBystatus= "asc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
				orderByPremiumStart="sort";
				orderBypremiumEnd="sort";
			} else if ("asc".equals(orderBystatus)) {
				orderBystatus = "desc";
				orderByinsurance_id  = "sort";
				orderByinsurance_Name="sort";
				orderBytype="sort";
				orderByPremiumStart="sort";
				orderBypremiumEnd="sort";
			}
			sessionMap.put("orderBystatus", orderBystatus);
			return "ShowDetailsPaging.jsp?faces-redirect=true";
		}
	}























		 		 