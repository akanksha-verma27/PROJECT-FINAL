package com.java.ips;

import java.io.Serializable;

public class Insurance_Plans implements Serializable{

	private int plan_id;
	private String insurance_id;
	private double premium_Amount;
	private String coverage_Amount;
	private String benefits;
	private String special_Offers;
	public int getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(int plan_id) {
		this.plan_id = plan_id;
	}
	public String getInsurance_id() {
		return insurance_id;
	}
	public void setInsurance_id(String insurance_id) {
		this.insurance_id = insurance_id;
	}
	public double getPremium_Amount() {
		return premium_Amount;
	}
	public void setPremium_Amount(double premium_Amount) {
		this.premium_Amount = premium_Amount;
	}
	public String getCoverage_Amount() {
		return coverage_Amount;
	}
	public void setCoverage_Amount(String coverage_Amount) {
		this.coverage_Amount = coverage_Amount;
	}
	public String getBenefits() {
		return benefits;
	}
	public void setBenefits(String benefits) {
		this.benefits = benefits;
	}
	public String getSpecial_Offers() {
		return special_Offers;
	}
	public void setSpecial_Offers(String special_Offers) {
		this.special_Offers = special_Offers;
	}
	@Override
	public String toString() {
		return "Insurance_Plans [plan_id=" + plan_id + ", insurance_id=" + insurance_id + ", premium_Amount="
				+ premium_Amount + ", coverage_Amount=" + coverage_Amount + ", benefits=" + benefits
				+ ", special_Offers=" + special_Offers + "]";
	}
	public Insurance_Plans(int plan_id, String insurance_id, double premium_Amount, String coverage_Amount,
			String benefits, String special_Offers) {
		super();
		this.plan_id = plan_id;
		this.insurance_id = insurance_id;
		this.premium_Amount = premium_Amount;
		this.coverage_Amount = coverage_Amount;
		this.benefits = benefits;
		this.special_Offers = special_Offers;
	}
	public Insurance_Plans() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}